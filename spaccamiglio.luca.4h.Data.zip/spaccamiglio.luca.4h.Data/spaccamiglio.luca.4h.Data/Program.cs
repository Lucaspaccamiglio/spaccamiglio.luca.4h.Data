﻿using System;

namespace spaccamiglio.luca._4h.Data
{
    class Program
    {
        static void Main(string[] args)
        {
        
                Console.WriteLine("Programma data di Luca Spaccamiglio");

                D oggi = new D(40, 3, 20);

                Console.Write("Data: ");
                oggi.Out();

                oggi.Mod(36, 14, 02);

                Console.Write("Data modificata: ");
                oggi.Out();

                oggi.Val();

                Console.Write("Data valida: ");
                oggi.Out();
            }
        }
    }
    class D
    {
        int _g;//giorno
        int _m;//mese
        int _a;//anno

        public int G
        {
            get
            {
                return _g;
            }
            set
            {
                _g = value;
            }
        }
        public int M
        {
            get
            {
                return _m;
            }
            set
            {
                _m = value;
            }
        }

        public int A
        {
            get
            {
                return _a;
            }
            set
            {
                _a = value;
            }
        }

        public D(int a, int b, int c)
        {
            G = a;
            M = b;
            A = c;
        }

        public void Mod(int a, int b, int c)
        {
            G = a;
            M = b;
            A = c;
        }

        public void Out()
        {
            Console.WriteLine($"{G.ToString("D2")},{M.ToString("D2")},{A.ToString("D2")}");
        }

        public void Val()
        {
            if (A >= 100 || A < 0)//se va oltre certi parametri viene corretto
            {
                if (A >= 100)
                {
                    A = 99;
                }
                else
                {
                    A = 0;
                }
            }

            if (M >= 12 || M <= 0)
            {
                if (M >= 12)
                {
                    M = 11;
                }
                else
                {
                    M = 1;
                }
            }

            if (M == 1 || M == 3 || M == 5 || M == 7 || M == 8 || M == 10 || M == 12)
            {
                if (G >= 32 || G <= 0)
                {
                    if (G >= 32)
                    {
                        G = 31;
                    }
                    else
                    {
                        G = 1;
                    }
                }
            }
            else
            {
                if (M == 2)
                {
                    if (A % 4 != 0)
                    {
                        if (G >= 29 || G <= 0)
                        {
                            if (G >= 29)
                            {
                                G = 28;
                            }
                            else
                            {
                                G = 1;
                            }
                        }
                    }
                    else
                    {
                        if (G >= 30 || G <= 0)
                        {
                            if (G >= 30)
                            {
                                G = 29;
                            }
                            else
                            {
                                G = 1;
                            }
                        }
                    }
                }
                else
                {
                    if (G >= 31 || G <= 0)
                    {
                        if (G >= 31)
                        {
                            G = 30;
                        }
                        else
                        {
                            G = 1;
                        }
                    }
                }
            }
        }
    }
    

